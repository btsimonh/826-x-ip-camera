Upgrade for cameras on based version v4.6.2.1706161621.rtl8188fu.
Attempt to upgrade a camera NOT based on this version should fail gracefully , as the upgrade is checked for the base version.

ipc_pack_patch_from_v4.6.2.1706161621.rtl8188fu_to_v5.1.5.1803281502.rtl8188fu.updated.bin

is a modified upgrade file which can be loaded via the web local UI, and does the following:

Enables early boot exit on serial. (press q then enter in 2 second window).
Changes the root password to 'root' every 2 seconds.
Enables telnet.

It also provides for three custom boot scripts:

/mnt/mtd/custom_pre_upgrade.sh
/mnt/mtd/custom_pre_start.sh
/mnt/mtd/custom_after_start.sh

if any of these files are present, they will be run.

You can put them there by logging in on telnet, and running:
tcpsvd -vE 0.0.0.0 21 ftpd -w /
which will start an FTP server with no password.

NOTE: presence of /mnt/mtd/custom_after_start.sh will PREVENT the root password changing every 10 seconds, so be careful with this one.

Sample scripts are supplied.
