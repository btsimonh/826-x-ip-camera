#!/bin/sh
echo test >/tmp/custom_pre_upgrade
