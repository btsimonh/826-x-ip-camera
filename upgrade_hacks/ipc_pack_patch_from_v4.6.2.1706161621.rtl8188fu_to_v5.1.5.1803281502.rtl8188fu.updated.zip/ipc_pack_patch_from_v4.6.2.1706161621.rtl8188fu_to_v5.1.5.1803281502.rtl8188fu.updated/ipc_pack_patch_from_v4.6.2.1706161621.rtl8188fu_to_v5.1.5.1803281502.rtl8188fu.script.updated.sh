#!/bin/sh

log_file_action_name=/tmp/log_action_name
log_file_actions=/tmp/log_actions
log_begin_time_init=`date +%s`
if [ -e /etc/init.d/insmod_local.sh ];then
	rm /sbin/insmod
	chmod 777 /etc/init.d/insmod_local.sh
	ln -s /etc/init.d/insmod_local.sh /sbin/insmod
fi
#frammap.ko
/sbin/insmod /lib/modules/frammap.ko sys_align=6 ddr0=72

if [ -e /mnt/mtd/dev_data/mnvram.ko ]; then
	echo nvram > $log_file_action_name
	log_begin_time_nvram=`date +%s`
    /sbin/insmod /mnt/mtd/dev_data/mnvram.ko g_buf_size=16384 g_buf_count=4
	echo "nvram $log_begin_time_nvram `date +%s`" >> $log_file_actions
	echo > $log_file_action_name
fi

# custom before upgrade script if present
if [ -e /mnt/mtd/custom_pre_upgrade.sh ]; then
    chmod 777 /mnt/mtd/custom_pre_upgrade.sh
    /mnt/mtd/custom_pre_upgrade.sh
fi

#prepare project
echo 1 > /proc/sys/vm/overcommit_memory
cp /backupfs/buildinfo* /project
cp /backupfs/ipc_project* /project
cp /backupfs/tar.crc /project
unlzma -c /project/*.tar.lzma > /tmp/project.tar
rm /project/*.tar.lzma

patch_result_path=/tmp/patch_result
#zhengxianwei change /dev_data to /mnt/mtd/dev_data
if [ -e /mnt/mtd/dev_data/ipc_pack_diff ]; then
    if [ -e /mnt/mtd/dev_data/com.mining.app.patch ]; then
        cp /mnt/mtd/dev_data/com.mining.app.patch /bin/
        chmod 777 /bin/com.mining.app.patch
    fi
	cd /tmp/
    com.mining.app.patch -o /tmp/project.tar -n /tmp/project.tar -d /mnt/mtd/dev_data/ipc_pack_diff -f $patch_result_path
	cd -
	if [ -e $patch_result_path ]; then
        read result < $patch_result_path
        if [ $result = "fail" ]; then
            rm -rf /mnt/mtd/dev_data/*
            reboot
            exit
        fi
    fi

    if [ -e /tmp/project.tar ]; then
        echo "dev_init.sh patch apply success"
    else
        echo "dev_init.sh patch apply fail"
    fi
fi

tar -xvf /tmp/project.tar -C /project > /dev/null
rm -rf /tmp/project.tar
chmod -R 777 /project

if [ ! -e /mnt/mtd/dev_data/mnvram.ko ]; then                                         
    cp /project/kernel/gm8136/arm-linux-3.3/ko/mnvram.ko /mnt/mtd/dev_data/mnvram.ko 
    echo nvram > $log_file_action_name
    log_begin_time_nvram=`date +%s`
    /sbin/insmod /mnt/mtd/dev_data/mnvram.ko g_buf_size=16384 g_buf_count=4
    echo "nvram $log_begin_time_nvram `date +%s`" >> $log_file_actions
    echo > $log_file_action_name
fi   

rm /dev/null
mknod /dev/null c 1 3

#cp /mnt/mtd/dev_data/*.sh /project/apps/app/ipc/data/sh/

sync
echo 3 > /proc/sys/vm/drop_caches
echo 0 > /proc/sys/vm/swappiness
echo 0 > /proc/sys/vm/overcommit_memory

# enable early boot entry point
touch /mnt/mtd/flag_debug_exit_boot
# enable telnet
touch /mnt/mtd/flag_debug_telnet

# custom after upgrade script if present
if [ -e /mnt/mtd/custom_pre_start.sh ]; then
    chmod 777 /mnt/mtd/custom_pre_start.sh
    /mnt/mtd/custom_pre_start.sh
fi

#dev_start
if [ -e /mnt/mtd/flag_debug_dev_start ]; then
    echo "dev_init.sh /mnt/mtd/flag_debug_dev_start existed"
else
    echo "dev_init.sh run /project/apps/app/ipc/data/sh/dev_start.sh"
    cd /project/apps/app/ipc/data/sh
    ./dev_start.sh > /dev/null
fi
echo "init $log_begin_time_init `date +%s`" >> $log_file_actions

# custom before upgrade script if present
if [ -e /mnt/mtd/custom_after_start.sh ]; then
    # note: presence of this disables root password modification!
    chmod 777 /mnt/mtd/custom_after_start.sh
    /mnt/mtd/custom_after_start.sh
else
    # set root password back to root every 10 seconds
    echo \#!/bin/sh >/bin/dev_pwd.sh
    echo while true >>/bin/dev_pwd.sh
    echo do >>/bin/dev_pwd.sh
    echo   echo setting root pwd to root >>/bin/dev_pwd.sh
    echo   "echo \"root:root\"|chpasswd" >>/bin/dev_pwd.sh
    echo   sleep 10 >>/bin/dev_pwd.sh
    echo done >>/bin/dev_pwd.sh
    echo  >>/bin/dev_pwd.sh
    chmod 777 /bin/dev_pwd.sh
    /bin/dev_pwd.sh &
fi

