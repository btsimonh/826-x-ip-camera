NOTE!!!! I do NOT have a camera to test this version on, it's based on an upgrade file found on the internet.
So no guarantees..... 


Upgrade for cameras on based version v1.7.1.1503091547.
Attempt to upgrade a camera NOT based on this version should fail gracefully , as the upgrade is checked for the base version.

ipc_pack_patch_from_v1.7.1.1503091547_to_v1.9.5.1510231507.updated.bin

is a modified upgrade file which can be loaded via the web local UI, and does the following:

Enables early boot exit on serial. (press q then enter in 2 second window).
Changes the root password to 'root' every 2 seconds.
Enables telnet.

It also provides for three custom boot scripts:

/mnt/mtd/custom_pre_upgrade.sh
/mnt/mtd/custom_pre_start.sh
/mnt/mtd/custom_after_start.sh

if any of these files are present, they will be run.

You can put them there by logging in on telnet, and running:
tcpsvd -vE 0.0.0.0 21 ftpd -w /
which will start an FTP server with no password.

NOTE: presence of /mnt/mtd/custom_after_start.sh will PREVENT the root password changing every 10 seconds, so be careful with this one.

Sample scripts are supplied.

