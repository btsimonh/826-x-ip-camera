#prepare project
unlzma -c /project/*.tar.lzma > /tmp/project.tar
rm /project/*.tar.lzma
patch_result_path=/tmp/patch_result
if [ -e /dev_data/ipc_pack_diff ]; then
    if [ -e /dev_data/com.mining.app.patch ]; then
        cp /dev_data/com.mining.app.patch /bin/
        chmod 777 /bin/com.mining.app.patch
    fi
    com.mining.app.patch -o /tmp/project.tar -n /tmp/project.new.tar -d /dev_data/ipc_pack_diff -f $patch_result_path
    if [ -e $patch_result_path ]; then
        read result < $patch_result_path
        if [ $result = "fail" ]; then
            rm -rf /dev_data/*
            reboot
            exit
        fi
    fi
    
    if [ -e /tmp/project.new.tar ]; then
        echo "[`date '+%Y-%m-%d %H:%M:%S'` dev_init.sh]" patch apply success
        mv /tmp/project.new.tar /tmp/project.tar
    else
        echo "[`date '+%Y-%m-%d %H:%M:%S'` dev_init.sh]" patch apply fail
    fi
fi

tar -xvf /tmp/project.tar -C /project/
rm -rf /tmp/project.tar
chmod -R 777 /project

#dev_start
if [ -e /mnt/mtd/flag_debug_dev_start ]; then
    echo "[`date '+%Y-%m-%d %H:%M:%S'` dev_init.sh]" /mnt/mtd/flag_debug_dev_start existed
else
    echo "[`date '+%Y-%m-%d %H:%M:%S'` dev_init.sh]" run /project/apps/app/ipc/data/sh/dev_start.sh
    cd /project/apps/app/ipc/data/sh
    ./dev_start.sh
fi
